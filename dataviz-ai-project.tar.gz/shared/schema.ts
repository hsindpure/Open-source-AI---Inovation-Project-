import { pgTable, text, serial, integer, boolean, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const dashboards = pgTable("dashboards", {
  id: serial("id").primaryKey(),
  filename: text("filename").notNull(),
  originalData: jsonb("original_data").notNull(),
  processedData: jsonb("processed_data").notNull(),
  aiRecommendation: text("ai_recommendation").notNull(),
  chartConfigs: jsonb("chart_configs").notNull(),
  kpis: jsonb("kpis").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const chatMessages = pgTable("chat_messages", {
  id: serial("id").primaryKey(),
  dashboardId: integer("dashboard_id").references(() => dashboards.id).notNull(),
  message: text("message").notNull(),
  response: text("response").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertDashboardSchema = createInsertSchema(dashboards).pick({
  filename: true,
  originalData: true,
  processedData: true,
  aiRecommendation: true,
  chartConfigs: true,
  kpis: true,
});

export const insertChatMessageSchema = createInsertSchema(chatMessages).pick({
  dashboardId: true,
  message: true,
  response: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertDashboard = z.infer<typeof insertDashboardSchema>;
export type Dashboard = typeof dashboards.$inferSelect;
export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;
export type ChatMessage = typeof chatMessages.$inferSelect;
