# DataViz AI - Excel Dashboard Generator

## Overview

This is an AI-powered web application that transforms Excel files into intelligent dashboards with interactive visualizations and an integrated AI chatbot. Users can upload Excel files (.xlsx), and the system automatically generates comprehensive dashboards with appropriate charts, KPIs, and data insights using OpenAI's capabilities.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript
- **Styling**: Tailwind CSS with shadcn/ui component library
- **State Management**: TanStack React Query for server state management
- **Routing**: Wouter for client-side routing
- **Build Tool**: Vite for development and bundling
- **UI Components**: Radix UI primitives with custom shadcn/ui styling

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **File Processing**: XLSX library for Excel file parsing
- **AI Integration**: OpenAI API for data analysis and recommendations
- **File Upload**: Multer middleware for handling file uploads

### Data Storage Solutions
- **Database**: PostgreSQL with Drizzle ORM
- **Schema Management**: Drizzle Kit for migrations
- **Connection**: Neon Database serverless driver
- **In-Memory Fallback**: MemStorage class for development/testing

### Authentication and Authorization
- Currently uses basic in-memory storage for users
- Session management with connect-pg-simple for PostgreSQL sessions
- Password-based authentication system ready for implementation

## Key Components

### Core Pages
1. **Landing Page**: Animated charts and call-to-action for user onboarding
2. **Upload Page**: Excel file upload interface with validation
3. **Dashboard Page**: Dynamic dashboard with AI-generated visualizations
4. **404 Page**: Error handling for unknown routes

### Data Processing Pipeline
1. **File Upload**: Multer handles Excel file uploads (10MB limit)
2. **Excel Parsing**: XLSX library converts Excel data to JSON
3. **AI Analysis**: OpenAI analyzes data structure and recommends visualizations
4. **Dashboard Generation**: System creates chart configurations and KPIs
5. **Storage**: Dashboard metadata and configurations stored in database

### AI Integration Components
- **Data Analysis**: Automatic detection of data types and characteristics
- **Visualization Recommendations**: AI suggests appropriate chart types
- **KPI Generation**: Automated key performance indicator creation
- **Chat Interface**: Interactive AI assistant for data exploration

## Data Flow

1. **User uploads Excel file** → File validation and processing
2. **Excel data conversion** → JSON format for AI processing
3. **AI analysis** → Data type classification and visualization recommendations
4. **Dashboard creation** → Chart configurations and KPI generation
5. **Data storage** → Dashboard metadata saved to database
6. **Dashboard rendering** → Dynamic visualization display
7. **Chat interaction** → AI-powered data insights and queries

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL database connection
- **drizzle-orm**: Type-safe ORM for database operations
- **xlsx**: Excel file processing and parsing
- **openai**: AI analysis and chat functionality
- **multer**: File upload handling

### UI Dependencies
- **@radix-ui/***: Accessible UI component primitives
- **@tanstack/react-query**: Server state management
- **tailwindcss**: Utility-first CSS framework
- **class-variance-authority**: Component variant styling
- **wouter**: Lightweight React router

### Development Dependencies
- **vite**: Fast build tool and development server
- **typescript**: Type safety and development tooling
- **drizzle-kit**: Database schema management
- **esbuild**: Production bundling for server code

## Deployment Strategy

### Build Process
- **Frontend**: Vite builds React app to `dist/public`
- **Backend**: esbuild bundles server code to `dist/index.js`
- **Database**: Drizzle migrations manage schema changes

### Environment Configuration
- **DATABASE_URL**: PostgreSQL connection string
- **OPENAI_API_KEY**: AI service authentication
- **NODE_ENV**: Environment-specific behavior control

### Production Setup
- Server serves static files from `dist/public`
- Express API routes handle backend functionality
- Database connections managed through environment variables
- File uploads processed in-memory with size limits

### Development Features
- Hot module replacement with Vite
- TypeScript type checking across full stack
- Error overlay for development debugging
- Cartographer integration for Replit environment