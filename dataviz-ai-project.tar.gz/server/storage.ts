import { dashboards, chatMessages, type Dashboard, type InsertDashboard, type ChatMessage, type InsertChatMessage, users, type User, type InsertUser } from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  createDashboard(dashboard: InsertDashboard): Promise<Dashboard>;
  getDashboard(id: number): Promise<Dashboard | undefined>;
  getAllDashboards(): Promise<Dashboard[]>;
  createChatMessage(message: InsertChatMessage): Promise<ChatMessage>;
  getChatMessages(dashboardId: number): Promise<ChatMessage[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private dashboards: Map<number, Dashboard>;
  private chatMessages: Map<number, ChatMessage>;
  private currentUserId: number;
  private currentDashboardId: number;
  private currentChatId: number;

  constructor() {
    this.users = new Map();
    this.dashboards = new Map();
    this.chatMessages = new Map();
    this.currentUserId = 1;
    this.currentDashboardId = 1;
    this.currentChatId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createDashboard(insertDashboard: InsertDashboard): Promise<Dashboard> {
    const id = this.currentDashboardId++;
    const dashboard: Dashboard = { 
      ...insertDashboard, 
      id, 
      createdAt: new Date() 
    };
    this.dashboards.set(id, dashboard);
    return dashboard;
  }

  async getDashboard(id: number): Promise<Dashboard | undefined> {
    return this.dashboards.get(id);
  }

  async getAllDashboards(): Promise<Dashboard[]> {
    return Array.from(this.dashboards.values());
  }

  async createChatMessage(insertMessage: InsertChatMessage): Promise<ChatMessage> {
    const id = this.currentChatId++;
    const message: ChatMessage = { 
      ...insertMessage, 
      id, 
      createdAt: new Date() 
    };
    this.chatMessages.set(id, message);
    return message;
  }

  async getChatMessages(dashboardId: number): Promise<ChatMessage[]> {
    return Array.from(this.chatMessages.values()).filter(
      (message) => message.dashboardId === dashboardId
    );
  }
}

export const storage = new MemStorage();
