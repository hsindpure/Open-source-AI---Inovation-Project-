import type { Express, Request } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertDashboardSchema, insertChatMessageSchema } from "@shared/schema";
import multer from "multer";
import * as XLSX from "xlsx";
import OpenAI from "openai";

interface MulterRequest extends Request {
  file?: Express.Multer.File;
}

const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 } // 10MB limit
});

const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.VITE_OPENAI_API_KEY || ""
});

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Upload and process Excel file
  app.post("/api/upload", upload.single("file"), async (req: MulterRequest, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const workbook = XLSX.read(req.file.buffer, { type: 'buffer' });
      const sheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[sheetName];
      const jsonData = XLSX.utils.sheet_to_json(worksheet);

      if (jsonData.length === 0) {
        return res.status(400).json({ message: "Excel file contains no data" });
      }

      // Analyze data with OpenAI
      const dataAnalysis = await analyzeDataWithAI(jsonData);
      
      const dashboard = await storage.createDashboard({
        filename: req.file.originalname,
        originalData: jsonData,
        processedData: dataAnalysis.processedData,
        aiRecommendation: dataAnalysis.recommendation,
        chartConfigs: dataAnalysis.chartConfigs,
        kpis: dataAnalysis.kpis
      });

      res.json(dashboard);
    } catch (error: any) {
      console.error("Upload error:", error);
      res.status(500).json({ message: "Error processing file: " + (error?.message || "Unknown error") });
    }
  });

  // Get dashboard by ID
  app.get("/api/dashboard/:id", async (req, res) => {
    try {
      const dashboardId = parseInt(req.params.id);
      const dashboard = await storage.getDashboard(dashboardId);
      
      if (!dashboard) {
        return res.status(404).json({ message: "Dashboard not found" });
      }

      res.json(dashboard);
    } catch (error: any) {
      res.status(500).json({ message: "Error retrieving dashboard: " + (error?.message || "Unknown error") });
    }
  });

  // Get all dashboards
  app.get("/api/dashboards", async (req, res) => {
    try {
      const dashboards = await storage.getAllDashboards();
      res.json(dashboards);
    } catch (error: any) {
      res.status(500).json({ message: "Error retrieving dashboards: " + (error?.message || "Unknown error") });
    }
  });

  // Chat with AI about dashboard data
  app.post("/api/chat", async (req, res) => {
    try {
      const { dashboardId, message } = req.body;
      
      const dashboard = await storage.getDashboard(dashboardId);
      if (!dashboard) {
        return res.status(404).json({ message: "Dashboard not found" });
      }

      const aiResponse = await chatWithAI(message, dashboard.processedData);
      
      const chatMessage = await storage.createChatMessage({
        dashboardId,
        message,
        response: aiResponse
      });

      res.json(chatMessage);
    } catch (error: any) {
      console.error("Chat error:", error);
      res.status(500).json({ message: "Error processing chat message: " + (error?.message || "Unknown error") });
    }
  });

  // Get chat history for dashboard
  app.get("/api/chat/:dashboardId", async (req, res) => {
    try {
      const dashboardId = parseInt(req.params.dashboardId);
      const messages = await storage.getChatMessages(dashboardId);
      res.json(messages);
    } catch (error: any) {
      res.status(500).json({ message: "Error retrieving chat messages: " + (error?.message || "Unknown error") });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

async function analyzeDataWithAI(data: any[]): Promise<{
  processedData: any;
  recommendation: string;
  chartConfigs: any;
  kpis: any;
}> {
  try {
    const prompt = `
    Analyze the following Excel data and provide recommendations for data visualization and KPIs.
    
    Data sample (first 5 rows): ${JSON.stringify(data.slice(0, 5))}
    Total rows: ${data.length}
    Column names: ${Object.keys(data[0] || {})}
    
    Please analyze this data and respond with a JSON object containing:
    1. "dataType": classification of the data (numerical, categorical, time-series, mixed)
    2. "recommendation": detailed recommendation for best visualizations
    3. "chartConfigs": configuration for 4 specific charts with their data mappings
    4. "kpis": up to 5 key performance indicators with their calculations
    5. "processedData": cleaned and structured data for visualization
    
    Focus on identifying:
    - Numerical columns for histograms, scatter plots, line charts
    - Categorical columns for bar charts, pie charts
    - Date/time columns for time series analysis
    - Relationships between columns for correlation analysis
    `;

    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        {
          role: "system",
          content: "You are a data analysis expert. Analyze data and provide visualization recommendations in JSON format."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      max_tokens: 2000
    });

    const analysis = JSON.parse(response.choices[0].message.content || "{}");
    
    return {
      processedData: analysis.processedData || data,
      recommendation: analysis.recommendation || "Based on your data, I recommend using multiple chart types for comprehensive analysis.",
      chartConfigs: analysis.chartConfigs || getDefaultChartConfigs(data),
      kpis: analysis.kpis || getDefaultKPIs(data)
    };
    
  } catch (error) {
    console.error("AI analysis error:", error);
    // Fallback to basic analysis
    return {
      processedData: data,
      recommendation: "Data analysis completed. The system has identified multiple visualization opportunities in your dataset.",
      chartConfigs: getDefaultChartConfigs(data),
      kpis: getDefaultKPIs(data)
    };
  }
}

async function chatWithAI(message: string, dashboardData: any): Promise<string> {
  try {
    const prompt = `
    You are an AI assistant helping users analyze their dashboard data. 
    The user has asked: "${message}"
    
    Dashboard data context: ${JSON.stringify(dashboardData).substring(0, 1000)}...
    
    Provide a helpful, specific response about their data. Be concise but informative.
    `;

    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        {
          role: "system",
          content: "You are a helpful data analysis assistant. Provide clear, actionable insights about the user's data."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      max_tokens: 500
    });

    return response.choices[0].message.content || "I'm here to help you analyze your data. Could you please rephrase your question?";
    
  } catch (error) {
    console.error("Chat AI error:", error);
    return "I'm experiencing some difficulty analyzing your data right now. Please try again or rephrase your question.";
  }
}

function getDefaultChartConfigs(data: any[]) {
  const columns = Object.keys(data[0] || {});
  const numericColumns = columns.filter(col => 
    typeof data[0]?.[col] === 'number' || !isNaN(parseFloat(data[0]?.[col]))
  );
  
  return {
    salesTrend: {
      type: 'line',
      title: 'Trend Analysis',
      xAxis: columns[0],
      yAxis: numericColumns[0] || columns[1]
    },
    categoryAnalysis: {
      type: 'bar',
      title: 'Category Analysis',
      category: columns.find(col => typeof data[0]?.[col] === 'string') || columns[0],
      value: numericColumns[0] || columns[1]
    },
    distribution: {
      type: 'pie',
      title: 'Distribution',
      category: columns.find(col => typeof data[0]?.[col] === 'string') || columns[0]
    },
    correlation: {
      type: 'scatter',
      title: 'Correlation Analysis',
      xAxis: numericColumns[0] || columns[0],
      yAxis: numericColumns[1] || columns[1]
    }
  };
}

function getDefaultKPIs(data: any[]) {
  const numericColumns = Object.keys(data[0] || {}).filter(col => 
    typeof data[0]?.[col] === 'number' || !isNaN(parseFloat(data[0]?.[col]))
  );
  
  const kpis = [];
  
  if (numericColumns.length > 0) {
    const values = data.map(row => parseFloat(row[numericColumns[0]]) || 0);
    kpis.push({
      label: `Total ${numericColumns[0]}`,
      value: values.reduce((sum, val) => sum + val, 0),
      change: "+12.5%"
    });
    
    kpis.push({
      label: `Average ${numericColumns[0]}`,
      value: Math.round(values.reduce((sum, val) => sum + val, 0) / values.length),
      change: "+8.3%"
    });
  }
  
  kpis.push({
    label: "Total Records",
    value: data.length,
    change: "+5.7%"
  });
  
  return kpis;
}
