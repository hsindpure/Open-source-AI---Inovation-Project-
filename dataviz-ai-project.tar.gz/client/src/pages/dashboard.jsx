import { useRoute } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import SalesTrendChart from "../components/charts/sales-trend-chart";
import CategoryChart from "../components/charts/category-chart";
import RegionalChart from "../components/charts/regional-chart";
import ScatterChart from "../components/charts/scatter-chart";
import Chatbot from "../components/chatbot";

export default function DashboardPage() {
  const [match, params] = useRoute("/dashboard/:id");
  const [activeFilters, setActiveFilters] = useState({});
  const [chartSelections, setChartSelections] = useState({});
  
  const { data: dashboard, isLoading, error } = useQuery({
    queryKey: ['/api/dashboard', params?.id],
    enabled: !!params?.id,
  });

  const hasActiveSelections = Object.keys(activeFilters).length > 0 || Object.keys(chartSelections).length > 0;

  const handleFilterChange = (filterType, value) => {
    if (value) {
      setActiveFilters(prev => ({ ...prev, [filterType]: value }));
    } else {
      setActiveFilters(prev => {
        const newFilters = { ...prev };
        delete newFilters[filterType];
        return newFilters;
      });
    }
  };

  const handleChartSelection = (chartType, selection) => {
    setChartSelections(prev => ({ ...prev, [chartType]: selection }));
  };

  const clearAllSelections = () => {
    setActiveFilters({});
    setChartSelections({});
    // Reset all select elements
    document.querySelectorAll('.filter-section select').forEach(select => {
      select.value = '';
    });
  };

  if (isLoading) {
    return (
      <div className="d-flex justify-content-center align-items-center" style={{ minHeight: '100vh' }}>
        <div className="loading-spinner"></div>
      </div>
    );
  }

  if (error || !dashboard) {
    return (
      <div className="container mt-5">
        <div className="alert alert-danger" role="alert">
          <i className="fas fa-exclamation-triangle me-2"></i>
          Dashboard not found or failed to load.
        </div>
      </div>
    );
  }

  return (
    <>
      <section className="dashboard-section" style={{ display: 'block', minHeight: '100vh', background: '#f8fafc', paddingTop: '2rem' }}>
        <div className="container-fluid">
          {/* Dashboard Header */}
          <div className="dashboard-header">
            <div className="container">
              <div className="row align-items-center">
                <div className="col-md-6">
                  <h3 className="mb-0">
                    <i className="fas fa-file-excel text-success me-2"></i>
                    {dashboard.filename}
                  </h3>
                </div>
                <div className="col-md-6 text-end">
                  <button className="btn btn-outline-secondary me-2" onClick={() => window.location.href = '/upload'}>
                    <i className="fas fa-upload"></i>
                    Upload New File
                  </button>
                  <button className="btn btn-primary" onClick={() => window.print()}>
                    <i className="fas fa-download"></i>
                    Export Dashboard
                  </button>
                </div>
              </div>
            </div>
          </div>
          
          <div className="container">
            {/* AI Recommendation */}
            <div className="alert alert-info" role="alert">
              <i className="fas fa-lightbulb me-2"></i>
              <strong>AI Recommendation:</strong> {dashboard.aiRecommendation}
            </div>
            
            {/* Selection Bar */}
            {hasActiveSelections && (
              <div className="selection-bar">
                <div className="d-flex align-items-center justify-content-between">
                  <div className="d-flex align-items-center flex-wrap">
                    <span className="text-white me-3">Active Selections:</span>
                    {Object.entries(activeFilters).map(([key, value]) => (
                      <div key={key} className="selection-tag">
                        {key}: {value}
                        <i 
                          className="fas fa-times ms-1" 
                          style={{ cursor: 'pointer' }}
                          onClick={() => handleFilterChange(key, '')}
                        ></i>
                      </div>
                    ))}
                    {Object.entries(chartSelections).map(([chart, selection]) => (
                      <div key={chart} className="selection-tag">
                        {chart}: {selection.name || selection.value}
                        <i 
                          className="fas fa-times ms-1" 
                          style={{ cursor: 'pointer' }}
                          onClick={() => setChartSelections(prev => {
                            const newSelections = { ...prev };
                            delete newSelections[chart];
                            return newSelections;
                          })}
                        ></i>
                      </div>
                    ))}
                  </div>
                  <button className="btn btn-outline-light btn-sm" onClick={clearAllSelections}>
                    Clear All
                  </button>
                </div>
              </div>
            )}
            
            {/* Filter Section */}
            <div className="filter-section">
              <h5 className="mb-3">
                <i className="fas fa-filter me-2"></i>
                Filters
              </h5>
              <div className="row">
                <div className="col-md-3">
                  <label className="form-label">Category</label>
                  <select 
                    className="form-select" 
                    onChange={(e) => handleFilterChange('category', e.target.value)}
                    value={activeFilters.category || ''}
                  >
                    <option value="">All Categories</option>
                    {dashboard.processedData && 
                      [...new Set(dashboard.processedData.map(row => Object.values(row)[0]))].map((category, i) => (
                        <option key={i} value={category}>{category}</option>
                      ))
                    }
                  </select>
                </div>
                <div className="col-md-3">
                  <label className="form-label">Date Range</label>
                  <select 
                    className="form-select" 
                    onChange={(e) => handleFilterChange('date', e.target.value)}
                    value={activeFilters.date || ''}
                  >
                    <option value="">All Dates</option>
                    <option value="last-month">Last Month</option>
                    <option value="last-quarter">Last Quarter</option>
                    <option value="last-year">Last Year</option>
                  </select>
                </div>
                <div className="col-md-3">
                  <label className="form-label">Value Range</label>
                  <select 
                    className="form-select" 
                    onChange={(e) => handleFilterChange('range', e.target.value)}
                    value={activeFilters.range || ''}
                  >
                    <option value="">All Values</option>
                    <option value="low">Low (0-25%)</option>
                    <option value="medium">Medium (25-75%)</option>
                    <option value="high">High (75-100%)</option>
                  </select>
                </div>
                <div className="col-md-3 d-flex align-items-end">
                  <button className="btn btn-outline-secondary w-100" onClick={clearAllSelections}>
                    <i className="fas fa-times me-2"></i>
                    Clear All Filters
                  </button>
                </div>
              </div>
            </div>
            
            {/* KPIs Section */}
            {dashboard.kpis && dashboard.kpis.length > 0 && (
              <div className="row mb-4">
                <div className="col-md-12">
                  <h5 className="mb-3">
                    <i className="fas fa-chart-bar me-2"></i>
                    Key Performance Indicators
                  </h5>
                </div>
                {dashboard.kpis.slice(0, 4).map((kpi, index) => (
                  <div key={index} className="col-md-3 col-sm-6 mb-3">
                    <div className="kpi-card">
                      <div className="kpi-value">{kpi.value}</div>
                      <div className="kpi-label">{kpi.label}</div>
                      {kpi.change && (
                        <small className={kpi.change.startsWith('+') ? 'text-success' : 'text-danger'}>
                          <i className={`fas fa-arrow-${kpi.change.startsWith('+') ? 'up' : 'down'}`}></i>
                          {kpi.change} from last period
                        </small>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
            
            {/* Charts Section */}
            <div className="row">
              <div className="col-md-12">
                <h5 className="mb-3">
                  <i className="fas fa-chart-line me-2"></i>
                  Interactive Charts
                </h5>
              </div>
              
              <div className="col-lg-6 col-md-12">
                <div className="chart-card">
                  <div className="chart-title">
                    <i className="fas fa-line-chart me-2"></i>
                    {dashboard.chartConfigs?.salesTrend?.title || 'Trend Analysis'}
                  </div>
                  <SalesTrendChart 
                    data={dashboard.processedData} 
                    config={dashboard.chartConfigs?.salesTrend}
                    filters={activeFilters}
                    onSelection={(selection) => handleChartSelection('trend', selection)}
                  />
                </div>
              </div>
              
              <div className="col-lg-6 col-md-12">
                <div className="chart-card">
                  <div className="chart-title">
                    <i className="fas fa-chart-bar me-2"></i>
                    {dashboard.chartConfigs?.categoryAnalysis?.title || 'Category Analysis'}
                  </div>
                  <CategoryChart 
                    data={dashboard.processedData} 
                    config={dashboard.chartConfigs?.categoryAnalysis}
                    filters={activeFilters}
                    onSelection={(selection) => handleChartSelection('category', selection)}
                  />
                </div>
              </div>
              
              <div className="col-lg-6 col-md-12">
                <div className="chart-card">
                  <div className="chart-title">
                    <i className="fas fa-chart-pie me-2"></i>
                    {dashboard.chartConfigs?.distribution?.title || 'Distribution'}
                  </div>
                  <RegionalChart 
                    data={dashboard.processedData} 
                    config={dashboard.chartConfigs?.distribution}
                    filters={activeFilters}
                    onSelection={(selection) => handleChartSelection('distribution', selection)}
                  />
                </div>
              </div>
              
              <div className="col-lg-6 col-md-12">
                <div className="chart-card">
                  <div className="chart-title">
                    <i className="fas fa-chart-scatter me-2"></i>
                    {dashboard.chartConfigs?.correlation?.title || 'Correlation Analysis'}
                  </div>
                  <ScatterChart 
                    data={dashboard.processedData} 
                    config={dashboard.chartConfigs?.correlation}
                    filters={activeFilters}
                    onSelection={(selection) => handleChartSelection('correlation', selection)}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      <Chatbot dashboardId={params?.id} />
    </>
  );
}
