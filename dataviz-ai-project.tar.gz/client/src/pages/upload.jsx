import { useState, useRef } from "react";
import { useLocation } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function UploadPage() {
  const [, setLocation] = useLocation();
  const [isDragging, setIsDragging] = useState(false);
  const [file, setFile] = useState(null);
  const fileInputRef = useRef(null);
  const { toast } = useToast();

  const uploadMutation = useMutation({
    mutationFn: async (file) => {
      const formData = new FormData();
      formData.append('file', file);
      
      const response = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Upload failed');
      }
      
      return response.json();
    },
    onSuccess: (dashboard) => {
      toast({
        title: "Success",
        description: "Your Excel file has been processed successfully!",
      });
      setLocation(`/dashboard/${dashboard.id}`);
    },
    onError: (error) => {
      toast({
        title: "Upload Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleFileSelect = (selectedFile) => {
    if (!selectedFile) return;
    
    if (!selectedFile.name.match(/\.(xlsx|xls)$/i)) {
      toast({
        title: "Invalid File Type",
        description: "Please select an Excel file (.xlsx or .xls)",
        variant: "destructive",
      });
      return;
    }
    
    if (selectedFile.size > 10 * 1024 * 1024) {
      toast({
        title: "File Too Large",
        description: "Please select a file smaller than 10MB",
        variant: "destructive",
      });
      return;
    }
    
    setFile(selectedFile);
    uploadMutation.mutate(selectedFile);
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setIsDragging(false);
    
    const droppedFile = e.dataTransfer.files[0];
    handleFileSelect(droppedFile);
  };

  const handleFileInputChange = (e) => {
    const selectedFile = e.target.files[0];
    handleFileSelect(selectedFile);
  };

  const handleBrowseClick = () => {
    fileInputRef.current?.click();
  };

  if (uploadMutation.isPending) {
    return (
      <section className="upload-section" style={{ display: 'block', minHeight: '100vh', background: '#f8fafc' }}>
        <div className="container">
          <div className="row">
            <div className="col-12">
              <div className="text-center mb-4">
                <h2 className="section-title">Processing Your Data</h2>
                <p className="section-subtitle">Our AI is analyzing your data and creating your dashboard</p>
              </div>
              
              <div className="upload-card">
                <div className="text-center">
                  <div className="loading-spinner"></div>
                  <h5>Processing Your Data...</h5>
                  <p className="text-muted">
                    Our AI is analyzing your Excel file and generating intelligent visualizations. 
                    This usually takes 30-60 seconds.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="upload-section" style={{ display: 'block', minHeight: '100vh', background: '#f8fafc', paddingTop: '4rem' }}>
      <div className="container">
        <div className="row">
          <div className="col-12">
            <div className="text-center mb-4">
              <h2 className="section-title">Upload Your Excel File</h2>
              <p className="section-subtitle">Upload your .xlsx file and let AI create your dashboard</p>
            </div>
            
            <div 
              className={`upload-card ${isDragging ? 'border-primary' : ''}`}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
            >
              <div className="text-center">
                <i className="fas fa-cloud-upload-alt upload-icon"></i>
                <h4 className="mb-3">Drag & Drop Your Excel File</h4>
                <p className="text-muted mb-4">or click to browse</p>
                
                <input 
                  type="file" 
                  ref={fileInputRef}
                  accept=".xlsx,.xls" 
                  style={{ display: 'none' }}
                  onChange={handleFileInputChange}
                />
                <button 
                  className="btn btn-primary btn-lg" 
                  onClick={handleBrowseClick}
                  disabled={uploadMutation.isPending}
                >
                  <i className="fas fa-folder-open me-2"></i>
                  Choose Excel File
                </button>
                
                <div className="mt-4">
                  <small className="text-muted">
                    <i className="fas fa-info-circle"></i>
                    {" "}Supported formats: .xlsx, .xls | Max file size: 10MB
                  </small>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
