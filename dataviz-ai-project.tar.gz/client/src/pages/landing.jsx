import { useLocation } from "wouter";
import { useEffect, useRef } from "react";

export default function LandingPage() {
  const [, setLocation] = useLocation();
  const heroChartRef = useRef(null);

  useEffect(() => {
    if (window.echarts && heroChartRef.current) {
      const heroChart = window.echarts.init(heroChartRef.current);
      const heroOption = {
        backgroundColor: 'transparent',
        xAxis: {
          type: 'category',
          data: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
          axisLine: { show: false },
          axisTick: { show: false },
          axisLabel: { color: '#ffffff', fontSize: 12 }
        },
        yAxis: {
          type: 'value',
          axisLine: { show: false },
          axisTick: { show: false },
          axisLabel: { color: '#ffffff', fontSize: 12 },
          splitLine: { lineStyle: { color: 'rgba(255, 255, 255, 0.1)' } }
        },
        series: [{
          data: [120, 132, 101, 134, 90, 230],
          type: 'line',
          smooth: true,
          lineStyle: {
            color: '#10b981',
            width: 3
          },
          itemStyle: {
            color: '#10b981'
          },
          areaStyle: {
            color: {
              type: 'linear',
              x: 0,
              y: 0,
              x2: 0,
              y2: 1,
              colorStops: [{
                offset: 0, color: 'rgba(16, 185, 129, 0.3)'
              }, {
                offset: 1, color: 'rgba(16, 185, 129, 0.05)'
              }]
            }
          }
        }],
        grid: {
          left: '3%',
          right: '4%',
          bottom: '3%',
          top: '3%',
          containLabel: true
        }
      };
      heroChart.setOption(heroOption);

      const handleResize = () => heroChart.resize();
      window.addEventListener('resize', handleResize);
      
      return () => {
        window.removeEventListener('resize', handleResize);
        heroChart.dispose();
      };
    }
  }, []);

  const handleGetStarted = () => {
    setLocation('/upload');
  };

  return (
    <>
      {/* Landing Page Section */}
      <section className="hero-section">
        <div className="container">
          <div className="row align-items-center">
            <div className="col-lg-6">
              <div className="hero-content">
                <h1 className="hero-title">
                  Transform Your Excel Data Into{' '}
                  <span style={{color: '#10b981'}}>Intelligent Dashboards</span>
                </h1>
                <p className="hero-subtitle">AI-Powered Analytics at Your Fingertips</p>
                <p className="hero-description">
                  Upload your Excel files and let our AI automatically generate beautiful, 
                  interactive dashboards with intelligent insights and recommendations. No coding required.
                </p>
                <button className="btn-get-started" onClick={handleGetStarted}>
                  <i className="fas fa-rocket"></i>
                  Get Started Free
                </button>
              </div>
            </div>
            <div className="col-lg-6">
              <div className="chart-container animated-chart">
                <div ref={heroChartRef} style={{width: '100%', height: '100%'}}></div>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Features Section */}
      <section className="py-5" style={{background: 'white'}}>
        <div className="container">
          <div className="text-center mb-5">
            <h2 className="section-title">Why Choose DataViz AI?</h2>
            <p className="section-subtitle">Powerful features that make data analysis effortless</p>
          </div>
          <div className="row">
            <div className="col-md-4 mb-4">
              <div className="feature-card">
                <i className="fas fa-brain feature-icon"></i>
                <h5>AI-Powered Analysis</h5>
                <p>Our advanced AI automatically identifies data patterns and recommends the best visualizations for your specific dataset.</p>
              </div>
            </div>
            <div className="col-md-4 mb-4">
              <div className="feature-card">
                <i className="fas fa-chart-line feature-icon"></i>
                <h5>Interactive Dashboards</h5>
                <p>Create stunning, interactive dashboards with drill-down capabilities and interconnected charts that update in real-time.</p>
              </div>
            </div>
            <div className="col-md-4 mb-4">
              <div className="feature-card">
                <i className="fas fa-comments feature-icon"></i>
                <h5>AI Chat Assistant</h5>
                <p>Ask questions about your data in natural language and get instant insights and explanations from our AI assistant.</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
