import { useState, useRef, useEffect } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

export default function Chatbot({ dashboardId }) {
  const [isOpen, setIsOpen] = useState(false);
  const [message, setMessage] = useState("");
  const [messages, setMessages] = useState([
    {
      type: 'ai',
      content: "Hello! I'm here to help you analyze your data. You can ask me questions like:\n• What are the key trends in my data?\n• Which categories perform best?\n• Show me correlations between variables\n• What insights can you find?"
    }
  ]);
  const messagesEndRef = useRef(null);

  const { data: chatHistory } = useQuery({
    queryKey: ['/api/chat', dashboardId],
    enabled: !!dashboardId && isOpen,
  });

  const sendMessageMutation = useMutation({
    mutationFn: async (messageText) => {
      const response = await apiRequest('POST', '/api/chat', {
        dashboardId: parseInt(dashboardId),
        message: messageText
      });
      return response.json();
    },
    onSuccess: (chatMessage) => {
      setMessages(prev => [...prev, 
        { type: 'user', content: chatMessage.message },
        { type: 'ai', content: chatMessage.response }
      ]);
    },
    onError: (error) => {
      setMessages(prev => [...prev, 
        { type: 'user', content: message },
        { type: 'ai', content: "I'm sorry, I'm having trouble processing your request right now. Please try again." }
      ]);
    }
  });

  useEffect(() => {
    if (chatHistory && chatHistory.length > 0) {
      const historyMessages = chatHistory.flatMap(chat => [
        { type: 'user', content: chat.message },
        { type: 'ai', content: chat.response }
      ]);
      setMessages(prev => [...prev.slice(0, 1), ...historyMessages]);
    }
  }, [chatHistory]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSendMessage = () => {
    if (!message.trim() || sendMessageMutation.isPending) return;
    
    const messageText = message.trim();
    setMessage("");
    sendMessageMutation.mutate(messageText);
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      handleSendMessage();
    }
  };

  const toggleChatbot = () => {
    setIsOpen(!isOpen);
  };

  return (
    <>
      {/* Chatbot Toggle Button */}
      {!isOpen && (
        <button className="chatbot-toggle" onClick={toggleChatbot}>
          <i className="fas fa-comments"></i>
        </button>
      )}
      
      {/* Chatbot Container */}
      {isOpen && (
        <div className="chatbot-container">
          <div className="chatbot-header">
            <div className="d-flex align-items-center">
              <i className="fas fa-robot me-2"></i>
              <div>
                <h6 className="mb-0">DataViz AI Assistant</h6>
                <small style={{ opacity: 0.8 }}>Ask questions about your data</small>
              </div>
            </div>
            <button className="btn btn-sm text-white" onClick={toggleChatbot}>
              <i className="fas fa-times"></i>
            </button>
          </div>
          
          <div className="chatbot-messages">
            {messages.map((msg, index) => (
              <div 
                key={index} 
                className={`chat-message message-${msg.type}`}
                style={{ 
                  marginLeft: msg.type === 'user' ? 'auto' : '0',
                  marginRight: msg.type === 'user' ? '0' : 'auto'
                }}
              >
                <div>
                  <strong>{msg.type === 'user' ? 'You' : 'AI Assistant'}:</strong>{' '}
                  {msg.content.split('\n').map((line, i) => (
                    <span key={i}>
                      {line}
                      {i < msg.content.split('\n').length - 1 && <br />}
                    </span>
                  ))}
                </div>
              </div>
            ))}
            {sendMessageMutation.isPending && (
              <div className="chat-message message-ai">
                <div>
                  <strong>AI Assistant:</strong> <i className="fas fa-spinner fa-spin"></i> Analyzing your question...
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
          
          <div className="chatbot-input">
            <div className="input-group">
              <input 
                type="text" 
                className="form-control" 
                placeholder="Ask about your data..." 
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                disabled={sendMessageMutation.isPending}
              />
              <button 
                className="btn btn-primary" 
                onClick={handleSendMessage}
                disabled={!message.trim() || sendMessageMutation.isPending}
              >
                <i className="fas fa-paper-plane"></i>
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
