import { useEffect, useRef } from "react";

export default function RegionalChart({ data, config, filters, onSelection }) {
  const chartRef = useRef(null);
  const chartInstance = useRef(null);

  useEffect(() => {
    if (!window.echarts || !chartRef.current || !data) return;

    if (chartInstance.current) {
      chartInstance.current.dispose();
    }

    const chart = window.echarts.init(chartRef.current);
    chartInstance.current = chart;

    // Filter data based on active filters
    let filteredData = data;
    if (filters && Object.keys(filters).length > 0) {
      filteredData = data.filter(row => {
        return Object.entries(filters).every(([filterKey, filterValue]) => {
          if (!filterValue) return true;
          
          const rowValues = Object.values(row);
          return rowValues.some(value => 
            String(value).toLowerCase().includes(filterValue.toLowerCase())
          );
        });
      });
    }

    // Process data for pie chart
    const processedData = processDataForPieChart(filteredData, config);

    const option = {
      title: {
        text: config?.title || 'Distribution',
        left: 'center',
        textStyle: {
          fontSize: 16,
          fontWeight: 'normal'
        }
      },
      tooltip: {
        trigger: 'item',
        formatter: '{a} <br/>{b}: {c} ({d}%)'
      },
      legend: {
        orient: 'vertical',
        left: 'left',
        top: 'middle'
      },
      series: [{
        name: config?.category || 'Category',
        type: 'pie',
        radius: ['40%', '70%'],
        data: processedData,
        emphasis: {
          itemStyle: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowColor: 'rgba(0, 0, 0, 0.5)'
          }
        },
        itemStyle: {
          borderRadius: 8,
          borderColor: '#fff',
          borderWidth: 2
        }
      }]
    };

    chart.setOption(option);

    // Handle chart clicks
    chart.on('click', function(params) {
      if (onSelection) {
        onSelection({
          type: 'distribution',
          name: params.name,
          value: params.value,
          percent: params.percent
        });
      }
    });

    const handleResize = () => chart.resize();
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      if (chartInstance.current) {
        chartInstance.current.dispose();
        chartInstance.current = null;
      }
    };
  }, [data, config, filters, onSelection]);

  return <div ref={chartRef} style={{ width: '100%', height: '350px' }}></div>;
}

function processDataForPieChart(data, config) {
  if (!data || data.length === 0) {
    return [];
  }

  const columns = Object.keys(data[0]);
  const categoryColumn = config?.category || columns.find(col => typeof data[0][col] === 'string') || columns[0];

  // Count occurrences of each category
  const counts = data.reduce((acc, row) => {
    const category = row[categoryColumn];
    if (!acc[category]) {
      acc[category] = 0;
    }
    acc[category]++;
    return acc;
  }, {});

  // Convert to pie chart format and add colors
  const colors = ['#3b82f6', '#f59e0b', '#10b981', '#8b5cf6', '#ef4444', '#06b6d4', '#f97316', '#84cc16'];
  
  return Object.entries(counts)
    .sort(([,a], [,b]) => b - a)
    .map(([name, value], index) => ({
      name,
      value,
      itemStyle: {
        color: colors[index % colors.length]
      }
    }));
}
