import { useEffect, useRef } from "react";

export default function CategoryChart({ data, config, filters, onSelection }) {
  const chartRef = useRef(null);
  const chartInstance = useRef(null);

  useEffect(() => {
    if (!window.echarts || !chartRef.current || !data) return;

    if (chartInstance.current) {
      chartInstance.current.dispose();
    }

    const chart = window.echarts.init(chartRef.current);
    chartInstance.current = chart;

    // Filter data based on active filters
    let filteredData = data;
    if (filters && Object.keys(filters).length > 0) {
      filteredData = data.filter(row => {
        return Object.entries(filters).every(([filterKey, filterValue]) => {
          if (!filterValue) return true;
          
          const rowValues = Object.values(row);
          return rowValues.some(value => 
            String(value).toLowerCase().includes(filterValue.toLowerCase())
          );
        });
      });
    }

    // Process data for bar chart
    const processedData = processDataForBarChart(filteredData, config);

    const option = {
      title: {
        text: config?.title || 'Category Analysis',
        left: 'center',
        textStyle: {
          fontSize: 16,
          fontWeight: 'normal'
        }
      },
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      xAxis: {
        type: 'category',
        data: processedData.categories,
        axisLabel: {
          rotate: 45
        }
      },
      yAxis: {
        type: 'value',
        name: config?.value || 'Count'
      },
      series: [{
        name: config?.value || 'Value',
        type: 'bar',
        data: processedData.values,
        itemStyle: {
          color: '#f59e0b'
        },
        emphasis: {
          itemStyle: {
            color: '#d97706'
          }
        }
      }]
    };

    chart.setOption(option);

    // Handle chart clicks
    chart.on('click', function(params) {
      if (onSelection) {
        onSelection({
          type: 'category',
          name: params.name,
          value: params.value
        });
      }
    });

    const handleResize = () => chart.resize();
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      if (chartInstance.current) {
        chartInstance.current.dispose();
        chartInstance.current = null;
      }
    };
  }, [data, config, filters, onSelection]);

  return <div ref={chartRef} style={{ width: '100%', height: '350px' }}></div>;
}

function processDataForBarChart(data, config) {
  if (!data || data.length === 0) {
    return { categories: [], values: [] };
  }

  const columns = Object.keys(data[0]);
  const categoryColumn = config?.category || columns.find(col => typeof data[0][col] === 'string') || columns[0];
  const valueColumn = config?.value || columns.find(col => typeof data[0][col] === 'number') || columns[1];

  // Group data by category and sum values
  const grouped = data.reduce((acc, row) => {
    const category = row[categoryColumn];
    const value = parseFloat(row[valueColumn]) || 1; // Default to 1 for counting
    
    if (!acc[category]) {
      acc[category] = 0;
    }
    acc[category] += value;
    return acc;
  }, {});

  // Sort by value descending
  const sortedEntries = Object.entries(grouped).sort(([,a], [,b]) => b - a);

  return {
    categories: sortedEntries.map(([category]) => category),
    values: sortedEntries.map(([, value]) => value)
  };
}
