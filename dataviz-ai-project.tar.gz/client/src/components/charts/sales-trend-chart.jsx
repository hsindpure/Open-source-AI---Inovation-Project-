import { useEffect, useRef } from "react";

export default function SalesTrendChart({ data, config, filters, onSelection }) {
  const chartRef = useRef(null);
  const chartInstance = useRef(null);

  useEffect(() => {
    if (!window.echarts || !chartRef.current || !data) return;

    if (chartInstance.current) {
      chartInstance.current.dispose();
    }

    const chart = window.echarts.init(chartRef.current);
    chartInstance.current = chart;

    // Filter data based on active filters
    let filteredData = data;
    if (filters && Object.keys(filters).length > 0) {
      filteredData = data.filter(row => {
        return Object.entries(filters).every(([filterKey, filterValue]) => {
          if (!filterValue) return true;
          
          // Apply filter logic based on the filter type
          const rowValues = Object.values(row);
          return rowValues.some(value => 
            String(value).toLowerCase().includes(filterValue.toLowerCase())
          );
        });
      });
    }

    // Process data for line chart
    const processedData = processDataForLineChart(filteredData, config);

    const option = {
      title: {
        text: config?.title || 'Trend Analysis',
        left: 'center',
        textStyle: {
          fontSize: 16,
          fontWeight: 'normal'
        }
      },
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'cross'
        }
      },
      legend: {
        data: processedData.series.map(s => s.name),
        top: 30
      },
      xAxis: {
        type: 'category',
        data: processedData.categories,
        axisLabel: {
          rotate: 45
        }
      },
      yAxis: {
        type: 'value',
        name: config?.yAxis || 'Value'
      },
      series: processedData.series.map(series => ({
        ...series,
        type: 'line',
        smooth: true,
        lineStyle: {
          color: series.color
        },
        itemStyle: {
          color: series.color
        }
      }))
    };

    chart.setOption(option);

    // Handle chart clicks
    chart.on('click', function(params) {
      if (onSelection) {
        onSelection({
          type: 'trend',
          category: params.name,
          value: params.value,
          seriesName: params.seriesName
        });
      }
    });

    const handleResize = () => chart.resize();
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      if (chartInstance.current) {
        chartInstance.current.dispose();
        chartInstance.current = null;
      }
    };
  }, [data, config, filters, onSelection]);

  return <div ref={chartRef} style={{ width: '100%', height: '350px' }}></div>;
}

function processDataForLineChart(data, config) {
  if (!data || data.length === 0) {
    return { categories: [], series: [] };
  }

  const columns = Object.keys(data[0]);
  const xAxisColumn = config?.xAxis || columns[0];
  const yAxisColumn = config?.yAxis || columns.find(col => typeof data[0][col] === 'number') || columns[1];

  // Group data by x-axis values
  const grouped = data.reduce((acc, row) => {
    const xValue = row[xAxisColumn];
    const yValue = parseFloat(row[yAxisColumn]) || 0;
    
    if (!acc[xValue]) {
      acc[xValue] = [];
    }
    acc[xValue].push(yValue);
    return acc;
  }, {});

  // Calculate aggregated values (sum, average, etc.)
  const categories = Object.keys(grouped);
  const values = categories.map(category => {
    const categoryValues = grouped[category];
    return categoryValues.reduce((sum, val) => sum + val, 0) / categoryValues.length;
  });

  return {
    categories,
    series: [{
      name: yAxisColumn,
      data: values,
      color: '#3b82f6'
    }]
  };
}
