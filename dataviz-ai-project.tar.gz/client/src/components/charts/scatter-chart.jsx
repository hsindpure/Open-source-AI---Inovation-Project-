import { useEffect, useRef } from "react";

export default function ScatterChart({ data, config, filters, onSelection }) {
  const chartRef = useRef(null);
  const chartInstance = useRef(null);

  useEffect(() => {
    if (!window.echarts || !chartRef.current || !data) return;

    if (chartInstance.current) {
      chartInstance.current.dispose();
    }

    const chart = window.echarts.init(chartRef.current);
    chartInstance.current = chart;

    // Filter data based on active filters
    let filteredData = data;
    if (filters && Object.keys(filters).length > 0) {
      filteredData = data.filter(row => {
        return Object.entries(filters).every(([filterKey, filterValue]) => {
          if (!filterValue) return true;
          
          const rowValues = Object.values(row);
          return rowValues.some(value => 
            String(value).toLowerCase().includes(filterValue.toLowerCase())
          );
        });
      });
    }

    // Process data for scatter plot
    const processedData = processDataForScatterChart(filteredData, config);

    const option = {
      title: {
        text: config?.title || 'Correlation Analysis',
        left: 'center',
        textStyle: {
          fontSize: 16,
          fontWeight: 'normal'
        }
      },
      tooltip: {
        trigger: 'item',
        formatter: function(params) {
          return `${config?.xAxis || 'X'}: ${params.data[0]}<br/>${config?.yAxis || 'Y'}: ${params.data[1]}`;
        }
      },
      xAxis: {
        type: 'value',
        name: config?.xAxis || 'X Axis',
        nameLocation: 'middle',
        nameGap: 30
      },
      yAxis: {
        type: 'value',
        name: config?.yAxis || 'Y Axis',
        nameLocation: 'middle',
        nameGap: 40
      },
      series: [{
        name: 'Data Points',
        type: 'scatter',
        data: processedData,
        symbolSize: 8,
        itemStyle: {
          color: '#8b5cf6',
          opacity: 0.7
        },
        emphasis: {
          itemStyle: {
            color: '#7c3aed',
            opacity: 1,
            shadowBlur: 10,
            shadowColor: 'rgba(139, 92, 246, 0.3)'
          }
        }
      }]
    };

    chart.setOption(option);

    // Handle chart clicks
    chart.on('click', function(params) {
      if (onSelection) {
        onSelection({
          type: 'correlation',
          x: params.data[0],
          y: params.data[1],
          point: params.data
        });
      }
    });

    const handleResize = () => chart.resize();
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      if (chartInstance.current) {
        chartInstance.current.dispose();
        chartInstance.current = null;
      }
    };
  }, [data, config, filters, onSelection]);

  return <div ref={chartRef} style={{ width: '100%', height: '350px' }}></div>;
}

function processDataForScatterChart(data, config) {
  if (!data || data.length === 0) {
    return [];
  }

  const columns = Object.keys(data[0]);
  const numericColumns = columns.filter(col => typeof data[0][col] === 'number' || !isNaN(parseFloat(data[0][col])));
  
  const xAxisColumn = config?.xAxis || numericColumns[0] || columns[0];
  const yAxisColumn = config?.yAxis || numericColumns[1] || columns[1];

  return data
    .map(row => {
      const x = parseFloat(row[xAxisColumn]);
      const y = parseFloat(row[yAxisColumn]);
      
      // Only include points where both values are valid numbers
      if (!isNaN(x) && !isNaN(y)) {
        return [x, y];
      }
      return null;
    })
    .filter(point => point !== null);
}
