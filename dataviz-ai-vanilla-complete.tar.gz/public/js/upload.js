// Upload page functionality
$(document).ready(function() {
    initializeUploadHandlers();
    setupDragAndDrop();
});

let isUploading = false;

function initializeUploadHandlers() {
    // Browse button click
    $('#browseBtn').on('click', function() {
        if (!isUploading) {
            $('#fileInput').click();
        }
    });

    // File input change
    $('#fileInput').on('change', function() {
        const file = this.files[0];
        if (file) {
            handleFileUpload(file);
        }
    });

    // Upload card click
    $('#uploadCard').on('click', function() {
        if (!isUploading) {
            $('#fileInput').click();
        }
    });
}

function setupDragAndDrop() {
    const uploadCard = $('#uploadCard')[0];

    // Prevent default drag behaviors
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        uploadCard.addEventListener(eventName, preventDefaults, false);
        document.body.addEventListener(eventName, preventDefaults, false);
    });

    // Highlight drop area when item is dragged over it
    ['dragenter', 'dragover'].forEach(eventName => {
        uploadCard.addEventListener(eventName, highlight, false);
    });

    ['dragleave', 'drop'].forEach(eventName => {
        uploadCard.addEventListener(eventName, unhighlight, false);
    });

    // Handle dropped files
    uploadCard.addEventListener('drop', handleDrop, false);
}

function preventDefaults(e) {
    e.preventDefault();
    e.stopPropagation();
}

function highlight(e) {
    $('#uploadCard').addClass('drag-over');
}

function unhighlight(e) {
    $('#uploadCard').removeClass('drag-over');
}

function handleDrop(e) {
    const dt = e.dataTransfer;
    const files = dt.files;

    if (files.length > 0) {
        handleFileUpload(files[0]);
    }
}

async function handleFileUpload(file) {
    if (isUploading) return;

    // Validate file
    const validation = api.validateExcelFile(file);
    if (!validation.valid) {
        api.showToast(validation.error, 'error');
        return;
    }

    // Show loading state
    showLoadingState();
    isUploading = true;

    try {
        // Upload file
        const dashboard = await api.uploadFile(file);
        
        // Show success message
        api.showToast('Your Excel file has been processed successfully!', 'success');
        
        // Redirect to dashboard
        setTimeout(() => {
            window.location.href = `dashboard.html?id=${dashboard.id}`;
        }, 1000);

    } catch (error) {
        console.error('Upload error:', error);
        api.showToast(error.message || 'Upload failed. Please try again.', 'error');
        hideLoadingState();
        isUploading = false;
    }
}

function showLoadingState() {
    $('#uploadCard').hide();
    $('#loadingCard').show();
    
    // Disable browse button
    $('#browseBtn').prop('disabled', true);
    
    // Add progress animation
    addProgressAnimation();
}

function hideLoadingState() {
    $('#loadingCard').hide();
    $('#uploadCard').show();
    
    // Re-enable browse button
    $('#browseBtn').prop('disabled', false);
}

function addProgressAnimation() {
    let progress = 0;
    const progressText = $('#loadingCard').find('p');
    const originalText = progressText.text();
    
    const updateProgress = () => {
        if (progress < 90 && isUploading) {
            progress += Math.random() * 10;
            progressText.html(`
                ${originalText}<br>
                <div class="progress mt-3">
                    <div class="progress-bar bg-primary" role="progressbar" 
                         style="width: ${Math.min(progress, 90)}%" 
                         aria-valuenow="${Math.min(progress, 90)}" 
                         aria-valuemin="0" 
                         aria-valuemax="100">
                        ${Math.round(Math.min(progress, 90))}%
                    </div>
                </div>
            `);
            
            setTimeout(updateProgress, 500 + Math.random() * 1000);
        }
    };
    
    setTimeout(updateProgress, 1000);
}

// File validation helpers
function validateFileType(file) {
    const allowedTypes = [
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'application/vnd.ms-excel'
    ];
    
    const allowedExtensions = ['.xlsx', '.xls'];
    const fileExtension = file.name.toLowerCase().substring(file.name.lastIndexOf('.'));
    
    return allowedTypes.includes(file.type) || allowedExtensions.includes(fileExtension);
}

function validateFileSize(file, maxSizeMB = 10) {
    const maxSizeBytes = maxSizeMB * 1024 * 1024;
    return file.size <= maxSizeBytes;
}

// Add file preview functionality
function showFilePreview(file) {
    const previewHTML = `
        <div class="file-preview mt-3 p-3 bg-light rounded">
            <div class="d-flex align-items-center">
                <i class="fas fa-file-excel text-success fs-2 me-3"></i>
                <div>
                    <h6 class="mb-1">${file.name}</h6>
                    <small class="text-muted">
                        Size: ${api.formatFileSize(file.size)} | 
                        Type: ${file.type || 'Excel file'}
                    </small>
                </div>
                <button class="btn btn-sm btn-outline-danger ms-auto" onclick="clearFilePreview()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        </div>
    `;
    
    $('#uploadCard').append(previewHTML);
}

function clearFilePreview() {
    $('.file-preview').remove();
    $('#fileInput').val('');
}

// Add upload tips
function showUploadTips() {
    const tipsHTML = `
        <div class="upload-tips mt-4">
            <h6><i class="fas fa-lightbulb text-warning me-2"></i>Tips for better results:</h6>
            <ul class="list-unstyled mt-3">
                <li class="mb-2">
                    <i class="fas fa-check text-success me-2"></i>
                    Include column headers in the first row
                </li>
                <li class="mb-2">
                    <i class="fas fa-check text-success me-2"></i>
                    Use consistent data formats (dates, numbers)
                </li>
                <li class="mb-2">
                    <i class="fas fa-check text-success me-2"></i>
                    Remove empty rows and columns
                </li>
                <li class="mb-2">
                    <i class="fas fa-check text-success me-2"></i>
                    Keep data in a single worksheet
                </li>
            </ul>
        </div>
    `;
    
    $('#uploadCard').append(tipsHTML);
}

// Initialize upload tips
$(document).ready(function() {
    setTimeout(showUploadTips, 2000);
});

// Handle keyboard accessibility
$(document).on('keydown', function(e) {
    if (e.key === 'Enter' || e.key === ' ') {
        if ($(e.target).is('#uploadCard, #browseBtn')) {
            e.preventDefault();
            $('#fileInput').click();
        }
    }
});

// Add sample data download link
function addSampleDataLink() {
    const sampleHTML = `
        <div class="text-center mt-4">
            <p class="text-muted">Don't have data? 
                <a href="#" id="downloadSample" class="text-primary">
                    <i class="fas fa-download me-1"></i>
                    Download sample Excel file
                </a>
            </p>
        </div>
    `;
    
    $('#uploadCard').append(sampleHTML);
    
    $('#downloadSample').on('click', function(e) {
        e.preventDefault();
        generateSampleExcelFile();
    });
}

function generateSampleExcelFile() {
    // Create sample data
    const sampleData = [
        ['Product', 'Category', 'Sales', 'Region', 'Date'],
        ['Laptop', 'Electronics', 1200, 'North', '2024-01-15'],
        ['Phone', 'Electronics', 800, 'South', '2024-01-16'],
        ['Desk', 'Furniture', 300, 'East', '2024-01-17'],
        ['Chair', 'Furniture', 150, 'West', '2024-01-18'],
        ['Tablet', 'Electronics', 600, 'North', '2024-01-19']
    ];
    
    // Create CSV content (simplified Excel format)
    const csvContent = sampleData.map(row => row.join(',')).join('\n');
    
    // Create download link
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'sample-data.csv';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
    
    api.showToast('Sample data file downloaded!', 'success');
}

// Initialize sample data link
$(document).ready(function() {
    setTimeout(addSampleDataLink, 3000);
});