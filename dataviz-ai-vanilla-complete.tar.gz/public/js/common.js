// Common utilities and API functions
class DataVizAPI {
    constructor() {
        this.baseURL = '';
    }

    // Show toast notification
    showToast(message, type = 'info') {
        const toastContainer = this.getOrCreateToastContainer();
        const toastId = 'toast-' + Date.now();
        
        const toastHTML = `
            <div class="toast ${type}" id="${toastId}" role="alert" aria-live="assertive" aria-atomic="true">
                <div class="toast-header">
                    <i class="fas fa-${this.getToastIcon(type)} me-2"></i>
                    <strong class="me-auto">${this.getToastTitle(type)}</strong>
                    <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
                </div>
                <div class="toast-body">
                    ${message}
                </div>
            </div>
        `;
        
        toastContainer.append(toastHTML);
        const toast = new bootstrap.Toast(document.getElementById(toastId));
        toast.show();
        
        // Auto remove after 5 seconds
        setTimeout(() => {
            $('#' + toastId).remove();
        }, 5000);
    }

    getOrCreateToastContainer() {
        let container = $('.toast-container');
        if (container.length === 0) {
            $('body').append('<div class="toast-container"></div>');
            container = $('.toast-container');
        }
        return container;
    }

    getToastIcon(type) {
        const icons = {
            success: 'check-circle',
            error: 'exclamation-triangle',
            warning: 'exclamation-circle',
            info: 'info-circle'
        };
        return icons[type] || 'info-circle';
    }

    getToastTitle(type) {
        const titles = {
            success: 'Success',
            error: 'Error',
            warning: 'Warning',
            info: 'Information'
        };
        return titles[type] || 'Information';
    }

    // Upload Excel file
    async uploadFile(file) {
        const formData = new FormData();
        formData.append('file', file);

        try {
            const response = await fetch('/api/upload', {
                method: 'POST',
                body: formData
            });

            if (!response.ok) {
                const error = await response.json();
                throw new Error(error.message || 'Upload failed');
            }

            return await response.json();
        } catch (error) {
            console.error('Upload error:', error);
            throw error;
        }
    }

    // Get dashboard data
    async getDashboard(id) {
        try {
            const response = await fetch(`/api/dashboard/${id}`);
            
            if (!response.ok) {
                const error = await response.json();
                throw new Error(error.message || 'Failed to load dashboard');
            }

            return await response.json();
        } catch (error) {
            console.error('Dashboard fetch error:', error);
            throw error;
        }
    }

    // Send chat message
    async sendChatMessage(dashboardId, message) {
        try {
            const response = await fetch('/api/chat', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    dashboardId: parseInt(dashboardId),
                    message: message
                })
            });

            if (!response.ok) {
                const error = await response.json();
                throw new Error(error.message || 'Chat failed');
            }

            return await response.json();
        } catch (error) {
            console.error('Chat error:', error);
            throw error;
        }
    }

    // Get chat history
    async getChatHistory(dashboardId) {
        try {
            const response = await fetch(`/api/chat/${dashboardId}`);
            
            if (!response.ok) {
                const error = await response.json();
                throw new Error(error.message || 'Failed to load chat history');
            }

            return await response.json();
        } catch (error) {
            console.error('Chat history fetch error:', error);
            throw error;
        }
    }

    // Validate Excel file
    validateExcelFile(file) {
        if (!file) {
            return { valid: false, error: "No file provided" };
        }

        if (!file.name.match(/\.(xlsx|xls)$/i)) {
            return { valid: false, error: "Invalid file type. Please select an Excel file (.xlsx or .xls)" };
        }

        if (file.size > 10 * 1024 * 1024) {
            return { valid: false, error: "File too large. Please select a file smaller than 10MB" };
        }

        return { valid: true };
    }

    // Format file size
    formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    // Get URL parameters
    getUrlParameter(param) {
        const urlParams = new URLSearchParams(window.location.search);
        return urlParams.get(param);
    }

    // Set URL parameter
    setUrlParameter(param, value) {
        const url = new URL(window.location);
        url.searchParams.set(param, value);
        window.history.pushState({}, '', url);
    }

    // Remove URL parameter
    removeUrlParameter(param) {
        const url = new URL(window.location);
        url.searchParams.delete(param);
        window.history.pushState({}, '', url);
    }

    // Debounce function
    debounce(func, wait, immediate) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                timeout = null;
                if (!immediate) func(...args);
            };
            const callNow = immediate && !timeout;
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
            if (callNow) func(...args);
        };
    }

    // Deep clone object
    deepClone(obj) {
        return JSON.parse(JSON.stringify(obj));
    }

    // Check if object is empty
    isEmpty(obj) {
        return Object.keys(obj).length === 0;
    }

    // Format number with commas
    formatNumber(num) {
        return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    }

    // Generate random ID
    generateId() {
        return Math.random().toString(36).substr(2, 9);
    }
}

// Global API instance
window.api = new DataVizAPI();

// Global chart utilities
class ChartUtils {
    static getDefaultColors() {
        return [
            '#3b82f6', '#f59e0b', '#10b981', '#8b5cf6', 
            '#ef4444', '#06b6d4', '#f97316', '#84cc16'
        ];
    }

    static processDataForLineChart(data, config) {
        if (!data || data.length === 0) {
            return { categories: [], series: [] };
        }

        const columns = Object.keys(data[0]);
        const xAxisColumn = config?.xAxis || columns[0];
        const yAxisColumn = config?.yAxis || columns.find(col => typeof data[0][col] === 'number') || columns[1];

        // Group data by x-axis values
        const grouped = data.reduce((acc, row) => {
            const xValue = row[xAxisColumn];
            const yValue = parseFloat(row[yAxisColumn]) || 0;
            
            if (!acc[xValue]) {
                acc[xValue] = [];
            }
            acc[xValue].push(yValue);
            return acc;
        }, {});

        // Calculate aggregated values
        const categories = Object.keys(grouped);
        const values = categories.map(category => {
            const categoryValues = grouped[category];
            return categoryValues.reduce((sum, val) => sum + val, 0) / categoryValues.length;
        });

        return {
            categories,
            series: [{
                name: yAxisColumn,
                data: values,
                color: this.getDefaultColors()[0]
            }]
        };
    }

    static processDataForBarChart(data, config) {
        if (!data || data.length === 0) {
            return { categories: [], values: [] };
        }

        const columns = Object.keys(data[0]);
        const categoryColumn = config?.category || columns.find(col => typeof data[0][col] === 'string') || columns[0];
        const valueColumn = config?.value || columns.find(col => typeof data[0][col] === 'number') || columns[1];

        // Group data by category and sum values
        const grouped = data.reduce((acc, row) => {
            const category = row[categoryColumn];
            const value = parseFloat(row[valueColumn]) || 1;
            
            if (!acc[category]) {
                acc[category] = 0;
            }
            acc[category] += value;
            return acc;
        }, {});

        // Sort by value descending
        const sortedEntries = Object.entries(grouped).sort(([,a], [,b]) => b - a);

        return {
            categories: sortedEntries.map(([category]) => category),
            values: sortedEntries.map(([, value]) => value)
        };
    }

    static processDataForPieChart(data, config) {
        if (!data || data.length === 0) {
            return [];
        }

        const columns = Object.keys(data[0]);
        const categoryColumn = config?.category || columns.find(col => typeof data[0][col] === 'string') || columns[0];

        // Count occurrences of each category
        const counts = data.reduce((acc, row) => {
            const category = row[categoryColumn];
            if (!acc[category]) {
                acc[category] = 0;
            }
            acc[category]++;
            return acc;
        }, {});

        // Convert to pie chart format
        const colors = this.getDefaultColors();
        
        return Object.entries(counts)
            .sort(([,a], [,b]) => b - a)
            .map(([name, value], index) => ({
                name,
                value,
                itemStyle: {
                    color: colors[index % colors.length]
                }
            }));
    }

    static processDataForScatterChart(data, config) {
        if (!data || data.length === 0) {
            return [];
        }

        const columns = Object.keys(data[0]);
        const numericColumns = columns.filter(col => typeof data[0][col] === 'number' || !isNaN(parseFloat(data[0][col])));
        
        const xAxisColumn = config?.xAxis || numericColumns[0] || columns[0];
        const yAxisColumn = config?.yAxis || numericColumns[1] || columns[1];

        return data
            .map(row => {
                const x = parseFloat(row[xAxisColumn]);
                const y = parseFloat(row[yAxisColumn]);
                
                if (!isNaN(x) && !isNaN(y)) {
                    return [x, y];
                }
                return null;
            })
            .filter(point => point !== null);
    }
}

// Global chart utilities instance
window.ChartUtils = ChartUtils;

// Initialize common functionality when DOM is ready
$(document).ready(function() {
    // Add loading state to buttons on form submit
    $('form').on('submit', function() {
        const submitBtn = $(this).find('button[type="submit"]');
        submitBtn.prop('disabled', true);
        submitBtn.html('<i class="fas fa-spinner fa-spin"></i> Processing...');
    });

    // Auto-hide alerts after 5 seconds
    $('.alert').each(function() {
        const alert = $(this);
        setTimeout(() => {
            alert.fadeOut();
        }, 5000);
    });
});