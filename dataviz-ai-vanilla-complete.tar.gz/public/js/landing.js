// Landing page functionality
$(document).ready(function() {
    // Initialize hero chart
    initializeHeroChart();
    
    // Handle get started button click
    $('#getStartedBtn').on('click', function() {
        window.location.href = 'upload.html';
    });
    
    // Add scroll animations
    handleScrollAnimations();
});

function initializeHeroChart() {
    if (typeof echarts === 'undefined') {
        console.error('ECharts library not loaded');
        return;
    }

    const chartElement = document.getElementById('heroChart');
    if (!chartElement) {
        console.error('Hero chart element not found');
        return;
    }

    const heroChart = echarts.init(chartElement);
    
    const heroOption = {
        backgroundColor: 'transparent',
        xAxis: {
            type: 'category',
            data: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
            axisLine: { show: false },
            axisTick: { show: false },
            axisLabel: { 
                color: '#ffffff', 
                fontSize: 12 
            }
        },
        yAxis: {
            type: 'value',
            axisLine: { show: false },
            axisTick: { show: false },
            axisLabel: { 
                color: '#ffffff', 
                fontSize: 12 
            },
            splitLine: { 
                lineStyle: { 
                    color: 'rgba(255, 255, 255, 0.1)' 
                } 
            }
        },
        series: [{
            data: [120, 132, 101, 134, 90, 230],
            type: 'line',
            smooth: true,
            lineStyle: {
                color: '#10b981',
                width: 3
            },
            itemStyle: {
                color: '#10b981'
            },
            areaStyle: {
                color: {
                    type: 'linear',
                    x: 0,
                    y: 0,
                    x2: 0,
                    y2: 1,
                    colorStops: [{
                        offset: 0, 
                        color: 'rgba(16, 185, 129, 0.3)'
                    }, {
                        offset: 1, 
                        color: 'rgba(16, 185, 129, 0.05)'
                    }]
                }
            }
        }],
        grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            top: '3%',
            containLabel: true
        }
    };
    
    heroChart.setOption(heroOption);

    // Handle window resize
    const handleResize = api.debounce(() => {
        heroChart.resize();
    }, 250);
    
    $(window).on('resize', handleResize);
    
    // Animate chart on load
    setTimeout(() => {
        heroChart.setOption({
            series: [{
                animationDuration: 2000,
                animationEasing: 'cubicOut'
            }]
        });
    }, 500);
}

function handleScrollAnimations() {
    // Intersection Observer for fade-in animations
    if ('IntersectionObserver' in window) {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }
            });
        }, {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        });

        // Observe feature cards
        $('.feature-card').each(function() {
            const card = this;
            card.style.opacity = '0';
            card.style.transform = 'translateY(30px)';
            card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
            observer.observe(card);
        });
    }
}

// Handle hero section parallax effect (optional)
$(window).on('scroll', api.debounce(function() {
    const scrolled = $(window).scrollTop();
    const parallax = scrolled * 0.5;
    
    $('.hero-section').css('transform', `translateY(${parallax}px)`);
}, 10));

// Add smooth scrolling for anchor links
$('a[href^="#"]').on('click', function(e) {
    e.preventDefault();
    
    const target = $(this.getAttribute('href'));
    if (target.length) {
        $('html, body').animate({
            scrollTop: target.offset().top - 100
        }, 1000);
    }
});

// Add loading states to interactive elements
$('.btn-get-started').on('mouseenter', function() {
    $(this).addClass('shadow-lg');
}).on('mouseleave', function() {
    $(this).removeClass('shadow-lg');
});

// Feature card hover effects
$('.feature-card').on('mouseenter', function() {
    $(this).find('.feature-icon').addClass('fa-beat');
}).on('mouseleave', function() {
    $(this).find('.feature-icon').removeClass('fa-beat');
});

// Add typing effect to hero title (optional)
function addTypingEffect() {
    const titleElement = $('.hero-title');
    const originalText = titleElement.html();
    const words = originalText.split(' ');
    
    titleElement.html('');
    
    let wordIndex = 0;
    const typeWords = () => {
        if (wordIndex < words.length) {
            titleElement.append(words[wordIndex] + ' ');
            wordIndex++;
            setTimeout(typeWords, 150);
        }
    };
    
    setTimeout(typeWords, 1000);
}

// Preload next page resources
function preloadResources() {
    const link = document.createElement('link');
    link.rel = 'prefetch';
    link.href = 'upload.html';
    document.head.appendChild(link);
    
    // Preload upload page CSS
    const cssLink = document.createElement('link');
    cssLink.rel = 'prefetch';
    cssLink.href = 'css/styles.css';
    document.head.appendChild(cssLink);
}

// Initialize preloading after page load
$(window).on('load', function() {
    preloadResources();
});