// Dashboard page functionality
let dashboardData = null;
let chartInstances = {};
let activeFilters = {};
let chartSelections = {};
let dashboardId = null;

$(document).ready(function() {
    // Get dashboard ID from URL
    dashboardId = api.getUrlParameter('id');
    
    if (!dashboardId) {
        api.showToast('No dashboard ID provided', 'error');
        setTimeout(() => {
            window.location.href = 'index.html';
        }, 2000);
        return;
    }

    // Load dashboard data
    loadDashboard();
    
    // Initialize event handlers
    initializeEventHandlers();
    
    // Initialize chatbot
    initializeChatbot();
});

async function loadDashboard() {
    try {
        dashboardData = await api.getDashboard(dashboardId);
        
        // Update UI with dashboard data
        updateDashboardUI();
        
        // Initialize charts
        initializeCharts();
        
        // Load chat history
        loadChatHistory();
        
    } catch (error) {
        console.error('Dashboard load error:', error);
        api.showToast(error.message || 'Failed to load dashboard', 'error');
        
        setTimeout(() => {
            window.location.href = 'index.html';
        }, 3000);
    }
}

function updateDashboardUI() {
    // Update title
    $('#dashboardTitle').html(`
        <i class="fas fa-file-excel text-success me-2"></i>
        ${dashboardData.filename}
    `);
    
    // Show AI recommendation
    if (dashboardData.aiRecommendation) {
        $('#recommendationText').text(dashboardData.aiRecommendation);
        $('#aiRecommendation').show();
    }
    
    // Update filters with data
    updateFilters();
    
    // Update KPIs
    updateKPIs();
    
    // Update chart titles
    updateChartTitles();
}

function updateFilters() {
    if (!dashboardData.processedData || dashboardData.processedData.length === 0) return;
    
    // Get unique categories for category filter
    const categories = [...new Set(dashboardData.processedData.map(row => Object.values(row)[0]))];
    const categorySelect = $('#categoryFilter');
    categorySelect.empty().append('<option value="">All Categories</option>');
    
    categories.forEach(category => {
        if (category && category.toString().trim()) {
            categorySelect.append(`<option value="${category}">${category}</option>`);
        }
    });
}

function updateKPIs() {
    if (!dashboardData.kpis || dashboardData.kpis.length === 0) return;
    
    const kpiCards = $('#kpiCards');
    kpiCards.empty();
    
    dashboardData.kpis.slice(0, 4).forEach(kpi => {
        const changeClass = kpi.change && kpi.change.startsWith('+') ? 'text-success' : 'text-danger';
        const changeIcon = kpi.change && kpi.change.startsWith('+') ? 'fa-arrow-up' : 'fa-arrow-down';
        
        const kpiHTML = `
            <div class="col-md-3 col-sm-6 mb-3">
                <div class="kpi-card">
                    <div class="kpi-value">${api.formatNumber(kpi.value)}</div>
                    <div class="kpi-label">${kpi.label}</div>
                    ${kpi.change ? `
                        <small class="${changeClass}">
                            <i class="fas ${changeIcon}"></i>
                            ${kpi.change} from last period
                        </small>
                    ` : ''}
                </div>
            </div>
        `;
        
        kpiCards.append(kpiHTML);
    });
    
    $('#kpiSection').show();
}

function updateChartTitles() {
    if (dashboardData.chartConfigs) {
        if (dashboardData.chartConfigs.salesTrend) {
            $('#trendChartTitle').html(`
                <i class="fas fa-line-chart me-2"></i>
                ${dashboardData.chartConfigs.salesTrend.title || 'Trend Analysis'}
            `);
        }
        
        if (dashboardData.chartConfigs.categoryAnalysis) {
            $('#categoryChartTitle').html(`
                <i class="fas fa-chart-bar me-2"></i>
                ${dashboardData.chartConfigs.categoryAnalysis.title || 'Category Analysis'}
            `);
        }
        
        if (dashboardData.chartConfigs.distribution) {
            $('#distributionChartTitle').html(`
                <i class="fas fa-chart-pie me-2"></i>
                ${dashboardData.chartConfigs.distribution.title || 'Distribution'}
            `);
        }
        
        if (dashboardData.chartConfigs.correlation) {
            $('#correlationChartTitle').html(`
                <i class="fas fa-chart-scatter me-2"></i>
                ${dashboardData.chartConfigs.correlation.title || 'Correlation Analysis'}
            `);
        }
    }
}

function initializeCharts() {
    if (typeof echarts === 'undefined') {
        console.error('ECharts library not loaded');
        return;
    }
    
    // Initialize all charts
    initializeTrendChart();
    initializeCategoryChart();
    initializeDistributionChart();
    initializeCorrelationChart();
    
    // Handle window resize
    $(window).on('resize', api.debounce(() => {
        Object.values(chartInstances).forEach(chart => {
            if (chart && typeof chart.resize === 'function') {
                chart.resize();
            }
        });
    }, 250));
}

function initializeTrendChart() {
    const chartElement = document.getElementById('trendChart');
    if (!chartElement) return;
    
    const chart = echarts.init(chartElement);
    chartInstances.trend = chart;
    
    updateTrendChart();
    
    // Handle chart clicks
    chart.on('click', function(params) {
        handleChartSelection('trend', {
            type: 'trend',
            category: params.name,
            value: params.value,
            seriesName: params.seriesName
        });
    });
}

function updateTrendChart() {
    if (!chartInstances.trend || !dashboardData) return;
    
    const filteredData = getFilteredData();
    const config = dashboardData.chartConfigs?.salesTrend || {};
    const processedData = ChartUtils.processDataForLineChart(filteredData, config);
    
    const option = {
        title: {
            text: config.title || 'Trend Analysis',
            left: 'center',
            textStyle: { fontSize: 16, fontWeight: 'normal' }
        },
        tooltip: {
            trigger: 'axis',
            axisPointer: { type: 'cross' }
        },
        legend: {
            data: processedData.series.map(s => s.name),
            top: 30
        },
        xAxis: {
            type: 'category',
            data: processedData.categories,
            axisLabel: { rotate: 45 }
        },
        yAxis: {
            type: 'value',
            name: config.yAxis || 'Value'
        },
        series: processedData.series.map(series => ({
            ...series,
            type: 'line',
            smooth: true,
            lineStyle: { color: series.color },
            itemStyle: { color: series.color }
        }))
    };
    
    chartInstances.trend.setOption(option);
}

function initializeCategoryChart() {
    const chartElement = document.getElementById('categoryChart');
    if (!chartElement) return;
    
    const chart = echarts.init(chartElement);
    chartInstances.category = chart;
    
    updateCategoryChart();
    
    chart.on('click', function(params) {
        handleChartSelection('category', {
            type: 'category',
            name: params.name,
            value: params.value
        });
    });
}

function updateCategoryChart() {
    if (!chartInstances.category || !dashboardData) return;
    
    const filteredData = getFilteredData();
    const config = dashboardData.chartConfigs?.categoryAnalysis || {};
    const processedData = ChartUtils.processDataForBarChart(filteredData, config);
    
    const option = {
        title: {
            text: config.title || 'Category Analysis',
            left: 'center',
            textStyle: { fontSize: 16, fontWeight: 'normal' }
        },
        tooltip: {
            trigger: 'axis',
            axisPointer: { type: 'shadow' }
        },
        xAxis: {
            type: 'category',
            data: processedData.categories,
            axisLabel: { rotate: 45 }
        },
        yAxis: {
            type: 'value',
            name: config.value || 'Count'
        },
        series: [{
            name: config.value || 'Value',
            type: 'bar',
            data: processedData.values,
            itemStyle: { color: '#f59e0b' },
            emphasis: { itemStyle: { color: '#d97706' } }
        }]
    };
    
    chartInstances.category.setOption(option);
}

function initializeDistributionChart() {
    const chartElement = document.getElementById('distributionChart');
    if (!chartElement) return;
    
    const chart = echarts.init(chartElement);
    chartInstances.distribution = chart;
    
    updateDistributionChart();
    
    chart.on('click', function(params) {
        handleChartSelection('distribution', {
            type: 'distribution',
            name: params.name,
            value: params.value,
            percent: params.percent
        });
    });
}

function updateDistributionChart() {
    if (!chartInstances.distribution || !dashboardData) return;
    
    const filteredData = getFilteredData();
    const config = dashboardData.chartConfigs?.distribution || {};
    const processedData = ChartUtils.processDataForPieChart(filteredData, config);
    
    const option = {
        title: {
            text: config.title || 'Distribution',
            left: 'center',
            textStyle: { fontSize: 16, fontWeight: 'normal' }
        },
        tooltip: {
            trigger: 'item',
            formatter: '{a} <br/>{b}: {c} ({d}%)'
        },
        legend: {
            orient: 'vertical',
            left: 'left',
            top: 'middle'
        },
        series: [{
            name: config.category || 'Category',
            type: 'pie',
            radius: ['40%', '70%'],
            data: processedData,
            emphasis: {
                itemStyle: {
                    shadowBlur: 10,
                    shadowOffsetX: 0,
                    shadowColor: 'rgba(0, 0, 0, 0.5)'
                }
            },
            itemStyle: {
                borderRadius: 8,
                borderColor: '#fff',
                borderWidth: 2
            }
        }]
    };
    
    chartInstances.distribution.setOption(option);
}

function initializeCorrelationChart() {
    const chartElement = document.getElementById('correlationChart');
    if (!chartElement) return;
    
    const chart = echarts.init(chartElement);
    chartInstances.correlation = chart;
    
    updateCorrelationChart();
    
    chart.on('click', function(params) {
        handleChartSelection('correlation', {
            type: 'correlation',
            x: params.data[0],
            y: params.data[1],
            point: params.data
        });
    });
}

function updateCorrelationChart() {
    if (!chartInstances.correlation || !dashboardData) return;
    
    const filteredData = getFilteredData();
    const config = dashboardData.chartConfigs?.correlation || {};
    const processedData = ChartUtils.processDataForScatterChart(filteredData, config);
    
    const option = {
        title: {
            text: config.title || 'Correlation Analysis',
            left: 'center',
            textStyle: { fontSize: 16, fontWeight: 'normal' }
        },
        tooltip: {
            trigger: 'item',
            formatter: function(params) {
                return `${config.xAxis || 'X'}: ${params.data[0]}<br/>${config.yAxis || 'Y'}: ${params.data[1]}`;
            }
        },
        xAxis: {
            type: 'value',
            name: config.xAxis || 'X Axis',
            nameLocation: 'middle',
            nameGap: 30
        },
        yAxis: {
            type: 'value',
            name: config.yAxis || 'Y Axis',
            nameLocation: 'middle',
            nameGap: 40
        },
        series: [{
            name: 'Data Points',
            type: 'scatter',
            data: processedData,
            symbolSize: 8,
            itemStyle: { color: '#8b5cf6', opacity: 0.7 },
            emphasis: {
                itemStyle: {
                    color: '#7c3aed',
                    opacity: 1,
                    shadowBlur: 10,
                    shadowColor: 'rgba(139, 92, 246, 0.3)'
                }
            }
        }]
    };
    
    chartInstances.correlation.setOption(option);
}

function getFilteredData() {
    if (!dashboardData?.processedData || api.isEmpty(activeFilters)) {
        return dashboardData?.processedData || [];
    }
    
    return dashboardData.processedData.filter(row => {
        return Object.entries(activeFilters).every(([filterKey, filterValue]) => {
            if (!filterValue) return true;
            
            const rowValues = Object.values(row);
            return rowValues.some(value => 
                String(value).toLowerCase().includes(filterValue.toLowerCase())
            );
        });
    });
}

function initializeEventHandlers() {
    // Filter change handlers
    $('#categoryFilter, #dateFilter, #rangeFilter').on('change', function() {
        const filterId = this.id.replace('Filter', '');
        const value = $(this).val();
        
        handleFilterChange(filterId, value);
    });
    
    // Clear filters button
    $('#clearFiltersBtn, #clearSelectionsBtn').on('click', clearAllSelections);
}

function handleFilterChange(filterType, value) {
    if (value) {
        activeFilters[filterType] = value;
    } else {
        delete activeFilters[filterType];
    }
    
    updateSelectionBar();
    updateAllCharts();
}

function handleChartSelection(chartType, selection) {
    chartSelections[chartType] = selection;
    updateSelectionBar();
}

function updateSelectionBar() {
    const hasSelections = !api.isEmpty(activeFilters) || !api.isEmpty(chartSelections);
    
    if (hasSelections) {
        updateSelectionTags();
        $('#selectionBar').show();
    } else {
        $('#selectionBar').hide();
    }
}

function updateSelectionTags() {
    const tagsContainer = $('#selectionTags');
    tagsContainer.empty();
    
    // Add filter tags
    Object.entries(activeFilters).forEach(([key, value]) => {
        const tag = createSelectionTag(`${key}: ${value}`, () => {
            delete activeFilters[key];
            $(`#${key}Filter`).val('');
            updateSelectionBar();
            updateAllCharts();
        });
        tagsContainer.append(tag);
    });
    
    // Add chart selection tags
    Object.entries(chartSelections).forEach(([chart, selection]) => {
        const displayText = selection.name || selection.value || selection.category || 'Selection';
        const tag = createSelectionTag(`${chart}: ${displayText}`, () => {
            delete chartSelections[chart];
            updateSelectionBar();
        });
        tagsContainer.append(tag);
    });
}

function createSelectionTag(text, onRemove) {
    return $(`
        <div class="selection-tag">
            ${text}
            <i class="fas fa-times ms-1" style="cursor: pointer;"></i>
        </div>
    `).find('i').on('click', onRemove).end();
}

function clearAllSelections() {
    activeFilters = {};
    chartSelections = {};
    
    // Reset filter selects
    $('#categoryFilter, #dateFilter, #rangeFilter').val('');
    
    updateSelectionBar();
    updateAllCharts();
}

function updateAllCharts() {
    updateTrendChart();
    updateCategoryChart();
    updateDistributionChart();
    updateCorrelationChart();
}

// Chatbot functionality
function initializeChatbot() {
    $('#chatToggleBtn').on('click', toggleChatbot);
    $('#chatCloseBtn').on('click', toggleChatbot);
    $('#chatSendBtn').on('click', sendChatMessage);
    $('#chatInput').on('keypress', function(e) {
        if (e.which === 13) {
            sendChatMessage();
        }
    });
}

function toggleChatbot() {
    const container = $('#chatbotContainer');
    const toggle = $('#chatToggleBtn');
    
    if (container.is(':visible')) {
        container.hide();
        toggle.show();
    } else {
        container.show();
        toggle.hide();
        scrollChatToBottom();
    }
}

async function sendChatMessage() {
    const input = $('#chatInput');
    const message = input.val().trim();
    
    if (!message) return;
    
    // Clear input
    input.val('');
    
    // Add user message
    addChatMessage('user', message);
    
    // Show loading
    addChatMessage('ai', '<i class="fas fa-spinner fa-spin"></i> Analyzing your question...');
    
    try {
        const response = await api.sendChatMessage(dashboardId, message);
        
        // Remove loading message
        $('#chatMessages .chat-message:last').remove();
        
        // Add AI response
        addChatMessage('ai', response.response);
        
    } catch (error) {
        console.error('Chat error:', error);
        
        // Remove loading message
        $('#chatMessages .chat-message:last').remove();
        
        // Add error message
        addChatMessage('ai', "I'm sorry, I'm having trouble processing your request right now. Please try again.");
    }
}

function addChatMessage(type, content) {
    const messagesContainer = $('#chatMessages');
    const messageClass = type === 'user' ? 'message-user' : 'message-ai';
    const sender = type === 'user' ? 'You' : 'AI Assistant';
    
    const messageHTML = `
        <div class="chat-message ${messageClass}">
            <div>
                <strong>${sender}:</strong> ${content}
            </div>
        </div>
    `;
    
    messagesContainer.append(messageHTML);
    scrollChatToBottom();
}

function scrollChatToBottom() {
    const messagesContainer = $('#chatMessages')[0];
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

async function loadChatHistory() {
    try {
        const chatHistory = await api.getChatHistory(dashboardId);
        
        chatHistory.forEach(chat => {
            addChatMessage('user', chat.message);
            addChatMessage('ai', chat.response);
        });
        
    } catch (error) {
        console.error('Chat history load error:', error);
    }
}