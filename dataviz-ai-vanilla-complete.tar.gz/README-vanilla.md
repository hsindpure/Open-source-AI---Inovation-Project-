# DataViz AI - Vanilla JavaScript Version

This is the vanilla JavaScript version of the DataViz AI application that automatically generates intelligent dashboards from Excel files using AI.

## What's Included

This package contains a complete vanilla JavaScript implementation with:

- **Landing Page** (`public/index.html`) - Hero section with animated charts
- **Upload Page** (`public/upload.html`) - Drag-and-drop Excel file upload
- **Dashboard Page** (`public/dashboard.html`) - Interactive charts and AI chatbot
- **Backend API** (`server/`) - Node.js Express server with OpenAI integration

## Tech Stack

- **Frontend**: Vanilla JavaScript + jQuery
- **Styling**: Bootstrap 5 + Font Awesome icons
- **Charts**: ECharts library for interactive visualizations
- **Backend**: Node.js + Express + TypeScript
- **AI**: OpenAI API for data analysis and recommendations

## Quick Setup

### 1. Prerequisites
- Node.js 18+ installed
- OpenAI API key (get from https://platform.openai.com)

### 2. Installation
```bash
# Extract the archive
tar -xzf dataviz-ai-vanilla.tar.gz
cd dataviz-ai-vanilla

# Install dependencies
npm install
```

### 3. Environment Setup
Create a `.env` file or set environment variable:
```bash
export OPENAI_API_KEY="your-openai-api-key-here"
```

### 4. Run the Application
```bash
# Start development server
npm run dev

# Or for production
npm start
```

The application will be available at http://localhost:5000

## File Structure

```
public/
├── index.html          # Landing page
├── upload.html         # File upload page
├── dashboard.html      # Dashboard with charts
├── css/
│   └── styles.css      # Custom styles
└── js/
    ├── common.js       # Shared utilities and API client
    ├── landing.js      # Landing page functionality
    ├── upload.js       # File upload handling
    └── dashboard.js    # Dashboard charts and chatbot

server/
├── index.ts            # Express server setup
├── routes.ts           # API routes
├── storage.ts          # Data storage interface
└── vite.ts             # Development server config

shared/
└── schema.ts           # TypeScript schemas
```

## Features

### 🚀 Landing Page
- Animated hero section with sample charts
- Responsive design with smooth animations
- Call-to-action button to start uploading

### 📁 Upload Page
- Drag-and-drop Excel file upload
- File validation (format and size)
- Progress indicators during processing
- Sample data download option

### 📊 Dashboard Page
- Interactive ECharts visualizations:
  - Line charts for trends
  - Bar charts for categories
  - Pie charts for distributions
  - Scatter plots for correlations
- Dynamic filters and selections
- Key Performance Indicators (KPIs)
- AI-powered chatbot for data insights

### 🤖 AI Features
- Automatic data analysis and chart recommendations
- Natural language chat interface
- Intelligent KPI generation
- Smart visualization suggestions

## API Endpoints

- `POST /api/upload` - Upload and process Excel file
- `GET /api/dashboard/:id` - Get dashboard data
- `POST /api/chat` - Send message to AI chatbot
- `GET /api/chat/:dashboardId` - Get chat history

## Browser Support

- Chrome 80+
- Firefox 75+
- Safari 13+
- Edge 80+

## Deployment

### Local Development
```bash
npm run dev
```

### Production Build
```bash
npm run build
npm start
```

### Environment Variables
- `OPENAI_API_KEY` - Required for AI features
- `PORT` - Server port (default: 5000)
- `NODE_ENV` - Environment mode

## Troubleshooting

### Common Issues

1. **OpenAI API Errors**
   - Check your API key is valid
   - Ensure you have credits in your OpenAI account
   - Verify network connectivity

2. **File Upload Issues**
   - Ensure file is .xlsx or .xls format
   - Check file size is under 10MB
   - Verify the file contains data with headers

3. **Charts Not Loading**
   - Check browser console for JavaScript errors
   - Ensure ECharts library is loaded
   - Verify dashboard data is valid

### Support

If you encounter issues:
1. Check the browser console for errors
2. Verify your OpenAI API key is working
3. Ensure all dependencies are installed
4. Check that the server is running on the correct port

## License

This is an open-source project. Feel free to modify and distribute as needed.

## Version

Vanilla JavaScript version created: July 18, 2025
Original React version converted to pure JavaScript/jQuery implementation.